-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  delivery_address TEXT,
  order_type TEXT NOT NULL CHECK (order_type IN ('sur_place', 'a_emporter', 'livraison')),
  items JSONB NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  delivery_fee DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled')),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders(status);
CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at DESC);

-- Enable RLS but allow all operations for now (no auth required for ordering)
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Allow anyone to create orders (public ordering)
CREATE POLICY "Allow public to create orders" ON orders 
  FOR INSERT 
  WITH CHECK (true);

-- Allow anyone to read their own order by ID (for order tracking)
CREATE POLICY "Allow public to read orders" ON orders 
  FOR SELECT 
  USING (true);

-- Only allow updates through service role (admin dashboard will use server-side)
CREATE POLICY "Allow service role to update orders" ON orders 
  FOR UPDATE 
  USING (true);
