"use client"

import { useState } from "react"
import Image from "next/image"
import { Plus, Flame } from "lucide-react"
import { cn } from "@/lib/utils"

export interface MenuItem {
  id: number
  name: string
  description: string
  price: number
  image: string
  badge?: string
  category: string
}

const menuItems: MenuItem[] = [
  {
    id: 1,
    name: "Kebab Classique",
    description: "Viande de kebab, sauce au choix, crudités fraîches, dans un pain moelleux",
    price: 9,
    image: "/images/kebab.jpg",
    badge: "Best-seller",
    category: "Kebab",
  },
  {
    id: 2,
    name: "Kebab Épicé",
    description: "Viande marinée, sauce harissa, piments, oignons caramélisés",
    price: 8,
    image: "/images/kebab.jpg",
    badge: "Piquant",
    category: "Kebab",
  },
  {
    id: 3,
    name: "Tacos Nature",
    description: "Galette croustillante, viande grillée, fromage fondu, crème, sauce blanche",
    price: 8,
    image: "/images/tacos.jpg",
    badge: "Best-seller",
    category: "Tacos",
  },
  {
    id: 4,
    name: "Tacos Maxi",
    description: "Double viande, double fromage, frites dans le tacos, sauce au choix",
    price: 10.5,
    image: "/images/tacos.jpg",
    category: "Tacos",
  },
  {
    id: 5,
    name: "Burger Best Of",
    description: "Steak de bœuf 180g, cheddar, bacon croustillant, salade, tomate, sauce signature",
    price: 9,
    image: "/images/burger.jpg",
    badge: "Nouveau",
    category: "Burgers",
  },
  {
    id: 6,
    name: "Burger Double",
    description: "Double steak, double cheddar, cornichons, oignons, ketchup & moutarde",
    price: 11.5,
    image: "/images/burger.jpg",
    category: "Burgers",
  },
  {
    id: 7,
    name: "Box Kebab",
    description: "Kebab + frites dorées + boisson au choix. Le combo parfait",
    price: 11,
    image: "/images/box.jpg",
    badge: "Économique",
    category: "Box",
  },
  {
    id: 8,
    name: "Box Burger",
    description: "Burger Best Of + frites + boisson au choix",
    price: 13,
    image: "/images/box.jpg",
    category: "Box",
  },
  {
    id: 9,
    name: "Frites Maison",
    description: "Pommes de terre fraîches, cuites à la perfection, légèrement salées",
    price: 3.5,
    image: "/images/frites.jpg",
    category: "Accompagnements",
  },
  {
    id: 10,
    name: "Tarte au Daim",
    description: "Tarte croustillante, caramel Daim, noisettes et éclats de chocolat",
    price: 4.5,
    image: "/images/tarte-daim.jpg",
    badge: "Coup de cœur",
    category: "Desserts",
  },
  {
    id: 11,
    name: "Tiramisu",
    description: "Tiramisu maison, biscuits imbibés, crème mascarpone, cacao amer",
    price: 4.5,
    image: "/images/tiramisu.jpg",
    category: "Desserts",
  },
]

const categories = ["Tous", "Kebab", "Tacos", "Burgers", "Box", "Accompagnements", "Desserts"]

interface MenuProps {
  onAddToCart: (item: MenuItem) => void
}

export function Menu({ onAddToCart }: MenuProps) {
  const [activeCategory, setActiveCategory] = useState("Tous")

  const filtered =
    activeCategory === "Tous"
      ? menuItems
      : menuItems.filter((i) => i.category === activeCategory)

  return (
    <section id="menu" className="py-24 px-4 md:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center mb-14">
        <span className="text-primary font-bold text-sm uppercase tracking-widest">Notre carte</span>
        <h2 className="font-black text-4xl md:text-5xl text-foreground mt-2 text-balance">
          Le Menu <span className="text-secondary">Best Of</span>
        </h2>
        <p className="text-muted-foreground mt-4 max-w-xl mx-auto text-pretty leading-relaxed">
          Des recettes authentiques, des ingrédients sélectionnés et des saveurs qui reviennent toujours.
        </p>
      </div>

      {/* Category tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-12">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={cn(
              "px-5 py-2 rounded-full font-semibold text-sm uppercase tracking-wider transition-all duration-200",
              activeCategory === cat
                ? "bg-primary text-primary-foreground scale-105"
                : "bg-brand-dark-surface text-muted-foreground hover:text-foreground hover:bg-muted"
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((item) => (
          <MenuCard key={item.id} item={item} onAdd={onAddToCart} />
        ))}
      </div>
    </section>
  )
}

function MenuCard({ item, onAdd }: { item: MenuItem; onAdd: (item: MenuItem) => void }) {
  return (
    <article className="group relative flex flex-col rounded-2xl overflow-hidden bg-card border border-border hover:border-primary/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10">
      {/* Image */}
      <div className="relative h-52 overflow-hidden">
        <Image
          src={item.image}
          alt={item.name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card/80 to-transparent" />
        {/* Badge */}
        {item.badge && (
          <span
            className={cn(
              "absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide",
              item.badge === "Piquant"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground"
            )}
          >
            {item.badge === "Piquant" && <Flame size={10} className="inline mr-1" />}
            {item.badge}
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-5 gap-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-bold text-lg text-foreground leading-tight">{item.name}</h3>
          <span className="font-black text-lg text-secondary shrink-0">
            {item.price.toFixed(2)}€
          </span>
        </div>
        <p className="text-muted-foreground text-sm leading-relaxed flex-1">
          {item.description}
        </p>
        <button
          onClick={() => onAdd(item)}
          className="mt-auto flex items-center justify-center gap-2 w-full py-3 bg-brand-dark-surface hover:bg-primary text-muted-foreground hover:text-primary-foreground font-semibold text-sm uppercase tracking-wider rounded-xl transition-all duration-300 border border-border hover:border-primary group/btn"
        >
          <Plus size={16} className="group-hover/btn:rotate-90 transition-transform duration-300" />
          Ajouter au panier
        </button>
      </div>
    </article>
  )
}
