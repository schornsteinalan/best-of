import { MapPin, Phone, Clock, ExternalLink } from "lucide-react"

const horaires = [
  { jour: "Lundi – Vendredi", heure: "11h00 – 23h00" },
  { jour: "Samedi", heure: "11h00 – 00h00" },
  { jour: "Dimanche", heure: "12h00 – 22h30" },
]

export function Contact() {
  return (
    <section id="contact" className="py-24 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="text-primary font-bold text-sm uppercase tracking-widest">Nous trouver</span>
          <h2 className="font-black text-4xl md:text-5xl text-foreground mt-2 text-balance">
            Venez nous <span className="text-secondary">rendre visite</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Info cards */}
          <div className="flex flex-col gap-5">
            {/* Address */}
            <div className="flex gap-4 p-6 rounded-2xl bg-card border border-border hover:border-primary/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <MapPin size={22} className="text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-foreground mb-1">Adresse</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  2 bis avenue aliénor <br />
                  33830 Belin Béliet, France
                </p>
                <a
                  href="https://maps.app.goo.gl/DXQLSn42rvUfLAy47"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-secondary text-sm font-medium mt-2 hover:underline"
                >
                  Ouvrir dans Maps <ExternalLink size={12} />
                </a>
              </div>
            </div>

            {/* Phone */}
            <div className="flex gap-4 p-6 rounded-2xl bg-card border border-border hover:border-primary/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <Phone size={22} className="text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-foreground mb-1">Téléphone</h3>
                <a
                  href="tel:+33123456789"
                  className="text-muted-foreground hover:text-secondary transition-colors text-sm"
                >
                  +33 7 88 02 37 63
                </a>
                <p className="text-muted-foreground text-xs mt-1">
                  Commandes & réservations par téléphone
                </p>
              </div>
            </div>

            {/* Horaires */}
            <div className="flex gap-4 p-6 rounded-2xl bg-card border border-border hover:border-primary/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <Clock size={22} className="text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-foreground mb-3">Horaires d&apos;ouverture</h3>
                <div className="flex flex-col gap-2">
                  {horaires.map(({ jour, heure }) => (
                    <div key={jour} className="flex items-center justify-between">
                      <span className="text-muted-foreground text-sm">{jour}</span>
                      <span className="text-secondary font-semibold text-sm">{heure}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Map embed */}
          <div className="rounded-2xl overflow-hidden border border-border min-h-80 relative">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2837.5!2d-0.7918043!3d44.4927729!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54f12bc28f2c41%3A0xe05b3c34ca9a9d7!2sBest%20of!5e0!3m2!1sfr!2sfr!4v1714000000000!5m2!1sfr!2sfr"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: "400px" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Localisation Best Of Restaurant"
              className="grayscale contrast-90 opacity-80 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
