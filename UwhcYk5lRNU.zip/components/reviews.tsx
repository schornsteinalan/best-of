import { Star } from "lucide-react"

const reviews = [
  {
    id: 1,
    name: "Karim B.",
    initials: "KB",
    rating: 5,
    date: "Il y a 2 jours",
    comment:
      "Le meilleur kebab de Paris sans hésitation ! La viande est toujours fraîche, la sauce maison est incroyable. J'y vais au moins 2 fois par semaine !",
  },
  {
    id: 2,
    name: "Sophie L.",
    initials: "SL",
    rating: 5,
    date: "Il y a 1 semaine",
    comment:
      "Tacos absolument délicieux, bien garnis et chauds à point. Le service est rapide et sympa. Je recommande la Box Burger aussi !",
  },
  {
    id: 3,
    name: "Mehdi R.",
    initials: "MR",
    rating: 5,
    date: "Il y a 2 semaines",
    comment:
      "Qualité constante à chaque visite. La tarte au Daim en dessert, c'est une révélation ! Un vrai best of dans tous les sens du terme.",
  },
  {
    id: 4,
    name: "Aïcha T.",
    initials: "AT",
    rating: 4,
    date: "Il y a 3 semaines",
    comment:
      "Très bon rapport qualité-prix. Les frites sont dorées parfaitement et le burger est juteux. Seul bémol, parfois un peu d'attente aux heures de pointe.",
  },
  {
    id: 5,
    name: "Lucas P.",
    initials: "LP",
    rating: 5,
    date: "Il y a 1 mois",
    comment:
      "Coup de cœur pour le kebab épicé ! Et le tiramisu maison... une merveille. L'ambiance est cool, le staff est accueillant. On reviendra c'est sûr.",
  },
  {
    id: 6,
    name: "Nina F.",
    initials: "NF",
    rating: 5,
    date: "Il y a 1 mois",
    comment:
      "Commande en ligne super simple, livraison rapide. Les produits arrivent chauds et bien emballés. Le meilleur snack du quartier !",
  },
]

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          size={14}
          className={i < rating ? "text-secondary fill-secondary" : "text-border fill-border"}
        />
      ))}
    </div>
  )
}

export function Reviews() {
  const avg = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)

  return (
    <section className="py-24 bg-brand-dark-card">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="text-primary font-bold text-sm uppercase tracking-widest">Témoignages</span>
          <h2 className="font-black text-4xl md:text-5xl text-foreground mt-2 text-balance">
            Ce que disent <span className="text-secondary">nos clients</span>
          </h2>
          {/* Global rating */}
          <div className="flex items-center justify-center gap-3 mt-6">
            <span className="font-black text-5xl text-secondary">{avg}</span>
            <div className="flex flex-col items-start gap-1">
              <div className="flex items-center gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={18} className="text-secondary fill-secondary" />
                ))}
              </div>
              <span className="text-muted-foreground text-sm">{reviews.length} avis vérifiés</span>
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review) => (
            <article
              key={review.id}
              className="flex flex-col gap-4 p-6 rounded-2xl bg-brand-dark-surface border border-border hover:border-secondary/30 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center font-bold text-sm text-primary-foreground">
                    {review.initials}
                  </div>
                  <div>
                    <p className="font-bold text-foreground text-sm">{review.name}</p>
                    <p className="text-muted-foreground text-xs">{review.date}</p>
                  </div>
                </div>
                <StarRating rating={review.rating} />
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed">
                &ldquo;{review.comment}&rdquo;
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
