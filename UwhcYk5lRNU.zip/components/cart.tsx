"use client"

import { useState } from "react"
import { X, Minus, Plus, ShoppingBag, Trash2, CheckCircle, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import type { MenuItem } from "./menu"

export interface CartItem extends MenuItem {
  quantity: number
}

interface CartProps {
  isOpen: boolean
  onClose: () => void
  items: CartItem[]
  onUpdateQuantity: (id: number, delta: number) => void
  onRemove: (id: number) => void
  onClearCart: () => void
}

type OrderType = "sur_place" | "a_emporter" | "livraison"

interface OrderForm {
  customer_name: string
  customer_phone: string
  customer_email: string
  delivery_address: string
  order_type: OrderType
  notes: string
}

export function Cart({ isOpen, onClose, items, onUpdateQuantity, onRemove, onClearCart }: CartProps) {
  const [showForm, setShowForm] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [orderSuccess, setOrderSuccess] = useState(false)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [form, setForm] = useState<OrderForm>({
    customer_name: "",
    customer_phone: "",
    customer_email: "",
    delivery_address: "",
    order_type: "a_emporter",
    notes: ""
  })

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const deliveryFee = form.order_type === "livraison" ? 3.50 : 0
  const total = subtotal + deliveryFee
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: items.map(item => ({
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity
          })),
          subtotal,
          delivery_fee: deliveryFee,
          total
        })
      })

      if (response.ok) {
        const data = await response.json()
        setOrderId(data.id)
        setOrderSuccess(true)
        onClearCart()
      }
    } catch (error) {
      console.error("Order submission failed:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const resetOrder = () => {
    setOrderSuccess(false)
    setOrderId(null)
    setShowForm(false)
    setForm({
      customer_name: "",
      customer_phone: "",
      customer_email: "",
      delivery_address: "",
      order_type: "a_emporter",
      notes: ""
    })
    onClose()
  }

  return (
    <>
      {/* Overlay */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300",
          isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
        onClick={onClose}
      />

      {/* Drawer */}
      <aside
        className={cn(
          "fixed top-0 right-0 h-full w-full max-w-md z-50 bg-brand-dark-card border-l border-border flex flex-col transition-transform duration-300 ease-out",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
        aria-label="Panier"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-border">
          <div className="flex items-center gap-3">
            <ShoppingBag size={22} className="text-primary" />
            <h2 className="font-black text-xl text-foreground">
              {orderSuccess ? "Commande envoyee" : showForm ? "Finaliser" : "Mon Panier"}
              {!showForm && !orderSuccess && totalItems > 0 && (
                <span className="ml-2 text-sm font-medium text-muted-foreground">
                  ({totalItems} article{totalItems > 1 ? "s" : ""})
                </span>
              )}
            </h2>
          </div>
          <button
            onClick={orderSuccess ? resetOrder : onClose}
            className="p-2 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            aria-label="Fermer le panier"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto py-4 px-6">
          {orderSuccess ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center">
                <CheckCircle size={48} className="text-green-500" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Commande envoyee !</h3>
              <p className="text-muted-foreground">
                Votre commande a ete transmise au restaurant.
              </p>
              {orderId && (
                <p className="text-sm text-muted-foreground">
                  Reference : <span className="font-mono text-secondary">{orderId.slice(0, 8)}</span>
                </p>
              )}
              <p className="text-sm text-muted-foreground mt-4">
                Nous vous contacterons au numero indique pour confirmer.
              </p>
              <button
                onClick={resetOrder}
                className="mt-4 px-6 py-3 bg-primary text-primary-foreground font-bold text-sm uppercase tracking-wider rounded-full hover:bg-primary/90 transition-colors"
              >
                Fermer
              </button>
            </div>
          ) : showForm ? (
            <form onSubmit={handleSubmitOrder} className="flex flex-col gap-4">
              {/* Order Type */}
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Type de commande
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: "sur_place", label: "Sur place" },
                    { value: "a_emporter", label: "A emporter" },
                    { value: "livraison", label: "Livraison" }
                  ].map(opt => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setForm(f => ({ ...f, order_type: opt.value as OrderType }))}
                      className={cn(
                        "py-2 px-3 rounded-lg text-sm font-medium transition-all border",
                        form.order_type === opt.value
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-brand-dark-surface border-border text-muted-foreground hover:border-primary/50"
                      )}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Nom complet *
                </label>
                <input
                  type="text"
                  required
                  value={form.customer_name}
                  onChange={e => setForm(f => ({ ...f, customer_name: e.target.value }))}
                  className="w-full px-4 py-3 rounded-lg bg-brand-dark-surface border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                  placeholder="Votre nom"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Telephone *
                </label>
                <input
                  type="tel"
                  required
                  value={form.customer_phone}
                  onChange={e => setForm(f => ({ ...f, customer_phone: e.target.value }))}
                  className="w-full px-4 py-3 rounded-lg bg-brand-dark-surface border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                  placeholder="06 XX XX XX XX"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Email (optionnel)
                </label>
                <input
                  type="email"
                  value={form.customer_email}
                  onChange={e => setForm(f => ({ ...f, customer_email: e.target.value }))}
                  className="w-full px-4 py-3 rounded-lg bg-brand-dark-surface border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                  placeholder="votre@email.com"
                />
              </div>

              {/* Delivery Address */}
              {form.order_type === "livraison" && (
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Adresse de livraison *
                  </label>
                  <textarea
                    required
                    value={form.delivery_address}
                    onChange={e => setForm(f => ({ ...f, delivery_address: e.target.value }))}
                    className="w-full px-4 py-3 rounded-lg bg-brand-dark-surface border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors resize-none"
                    rows={2}
                    placeholder="Adresse complete"
                  />
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Instructions (optionnel)
                </label>
                <textarea
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full px-4 py-3 rounded-lg bg-brand-dark-surface border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors resize-none"
                  rows={2}
                  placeholder="Allergies, sauce en plus..."
                />
              </div>

              {/* Summary */}
              <div className="mt-2 p-4 rounded-lg bg-brand-dark-surface border border-border">
                <h4 className="font-semibold text-foreground mb-2">Recapitulatif</h4>
                <ul className="text-sm text-muted-foreground space-y-1 mb-3">
                  {items.map(item => (
                    <li key={item.id} className="flex justify-between">
                      <span>{item.quantity}x {item.name}</span>
                      <span>{(item.price * item.quantity).toFixed(2)}EUR</span>
                    </li>
                  ))}
                </ul>
                <div className="border-t border-border pt-2 space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Sous-total</span>
                    <span className="text-foreground">{subtotal.toFixed(2)}EUR</span>
                  </div>
                  {form.order_type === "livraison" && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Livraison</span>
                      <span className="text-foreground">{deliveryFee.toFixed(2)}EUR</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold">
                    <span className="text-foreground">Total</span>
                    <span className="text-secondary">{total.toFixed(2)}EUR</span>
                  </div>
                </div>
              </div>
            </form>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <ShoppingBag size={56} className="text-border" />
              <p className="text-muted-foreground font-medium">Votre panier est vide</p>
              <p className="text-muted-foreground text-sm">
                Ajoutez des articles depuis notre menu
              </p>
              <button
                onClick={onClose}
                className="mt-2 px-6 py-3 bg-primary text-primary-foreground font-bold text-sm uppercase tracking-wider rounded-full hover:bg-primary/90 transition-colors"
              >
                Voir le menu
              </button>
            </div>
          ) : (
            <ul className="flex flex-col gap-4">
              {items.map((item) => (
                <li
                  key={item.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-brand-dark-surface border border-border"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm truncate">{item.name}</p>
                    <p className="text-secondary font-bold text-sm mt-0.5">
                      {(item.price * item.quantity).toFixed(2)}EUR
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onUpdateQuantity(item.id, -1)}
                      className="w-7 h-7 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors"
                      aria-label="Reduire la quantite"
                    >
                      <Minus size={12} />
                    </button>
                    <span className="font-bold text-foreground text-sm w-5 text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, 1)}
                      className="w-7 h-7 rounded-full bg-muted hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors"
                      aria-label="Augmenter la quantite"
                    >
                      <Plus size={12} />
                    </button>
                  </div>
                  <button
                    onClick={() => onRemove(item.id)}
                    className="p-1.5 text-muted-foreground hover:text-primary transition-colors"
                    aria-label="Supprimer l'article"
                  >
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Footer */}
        {!orderSuccess && items.length > 0 && (
          <div className="border-t border-border px-6 py-6 flex flex-col gap-4">
            {!showForm && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground font-medium">Sous-total</span>
                  <span className="font-black text-xl text-secondary">{subtotal.toFixed(2)}EUR</span>
                </div>
                <p className="text-muted-foreground text-xs">
                  Livraison et taxes calculees a la validation
                </p>
              </>
            )}
            
            {showForm ? (
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 py-4 bg-muted text-foreground font-bold text-sm uppercase tracking-wider rounded-full hover:bg-muted/80 transition-colors"
                >
                  Retour
                </button>
                <button
                  type="submit"
                  onClick={handleSubmitOrder}
                  disabled={isSubmitting || !form.customer_name || !form.customer_phone}
                  className="flex-1 py-4 bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-sm uppercase tracking-wider rounded-full transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={18} className="animate-spin" />
                      Envoi...
                    </>
                  ) : (
                    `Commander — ${total.toFixed(2)}EUR`
                  )}
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setShowForm(true)}
                className="w-full py-4 bg-primary hover:bg-primary/90 text-primary-foreground font-black text-base uppercase tracking-wider rounded-full transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-primary/30"
              >
                Valider la commande — {subtotal.toFixed(2)}EUR
              </button>
            )}
          </div>
        )}
      </aside>
    </>
  )
}
