import Link from "next/link"
import { Instagram, Facebook, Phone, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-brand-dark-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center font-black text-lg text-primary-foreground">
                B
              </div>
              <span className="font-black text-2xl tracking-tight text-foreground">
                BEST <span className="text-primary">OF</span>
              </span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed text-pretty">
              Le meilleur du snack, au meilleur goût. Kebabs, Tacos, Burgers —
              préparés avec passion depuis 2018.
            </p>
            <div className="flex items-center gap-3 mt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-brand-dark-surface border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-brand-dark-surface border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="font-bold text-foreground mb-5 uppercase tracking-widest text-sm">Navigation</h3>
            <ul className="flex flex-col gap-3">
              {[
                { href: "#accueil", label: "Accueil" },
                { href: "#menu", label: "Notre Menu" },
                { href: "#commander", label: "Commander en ligne" },
                { href: "#apropos", label: "À propos" },
                { href: "#contact", label: "Contact" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-muted-foreground hover:text-secondary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact info */}
          <div>
            <h3 className="font-bold text-foreground mb-5 uppercase tracking-widest text-sm">Contact</h3>
            <div className="flex flex-col gap-4">
              <a href="tel:+33123456789" className="flex items-center gap-3 text-muted-foreground hover:text-secondary transition-colors text-sm">
                <Phone size={16} className="text-primary shrink-0" />
                +33 7 88 02 37 63
              </a>
              <div className="flex items-start gap-3 text-muted-foreground text-sm">
                <MapPin size={16} className="text-primary shrink-0 mt-0.5" />
                2 bis avenue aliénor, 33830 Belin Béliet
              </div>
              <div className="mt-2 p-4 rounded-xl bg-brand-dark-surface border border-border">
                <p className="font-semibold text-foreground text-sm mb-2">Horaires</p>
                <p className="text-muted-foreground text-xs leading-relaxed">
                  Lun – Ven : 11h – 23h<br />
                  Samedi : 11h – 00h<br />
                  Dimanche : 12h – 22h30
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-muted-foreground text-xs">
            &copy; {new Date().getFullYear()} Best Of Restaurant. Tous droits réservés.
          </p>
          <div className="flex items-center gap-4">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-muted-foreground text-xs">Ouvert maintenant</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
