import { Tag } from "lucide-react"
import Link from "next/link"

const promos = [
  {
    label: "Menu du Jour",
    title: "Menu buckets duo à 18.50€",
    description: "18 Wings + 2 frites + 2 boisson. Valable des maintenant.",
    color: "bg-primary",
    textColor: "text-primary-foreground",
  },
  {
    label: "Offre spéciale",
    title: "Menu buckets famille à 29.90€",
    description: "35 wings + 4 frites + boisson 1.5 litre",
    color: "bg-secondary",
    textColor: "text-secondary-foreground",
  },
  {
    label: "Nouveau",
    title: "Crousty",
    description: "Nos nouveaux crousty sont disponible — donnez-nous votre avis !",
    color: "bg-brand-dark-surface",
    textColor: "text-foreground",
    border: true,
  },
]

export function PromoBanner() {
  return (
    <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Tag size={20} className="text-secondary" />
        <h2 className="font-black text-2xl text-foreground">
          Offres & Promotions
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {promos.map((promo) => (
          <div
            key={promo.title}
            className={`flex flex-col gap-3 p-6 rounded-2xl ${promo.color} ${promo.textColor} ${promo.border ? "border border-border" : ""} relative overflow-hidden`}
          >
            <span
              className={`inline-flex self-start px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${promo.border ? "bg-secondary text-secondary-foreground" : "bg-black/20"
                }`}
            >
              {promo.label}
            </span>
            <h3 className="font-black text-2xl leading-tight">{promo.title}</h3>
            <p className={`text-sm leading-relaxed ${promo.border ? "text-muted-foreground" : "opacity-80"}`}>
              {promo.description}
            </p>
            <Link
              href="#commander"
              className={`mt-2 self-start px-5 py-2 rounded-full text-sm font-bold uppercase tracking-wide transition-all duration-200 hover:scale-105 ${promo.border
                ? "bg-primary text-primary-foreground"
                : "bg-black/20 hover:bg-black/30"
                }`}
            >
              En profiter
            </Link>
          </div>
        ))}
      </div>
    </section>
  )
}
