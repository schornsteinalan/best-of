import { Zap, Leaf, Award, Clock } from "lucide-react"

const features = [
  {
    icon: Award,
    title: "Qualité Premium",
    description: "Viandes fraîches sélectionnées chaque jour, ingrédients locaux et recettes authentiques.",
  },
  {
    icon: Zap,
    title: "Service Ultra-rapide",
    description: "Votre commande prête en moins de 10 minutes. Rapide sans jamais sacrifier la qualité.",
  },
  {
    icon: Leaf,
    title: "Ingrédients Frais",
    description: "Légumes du jour, sauces maison et pain livré chaque matin. Rien de congelé.",
  },
  {
    icon: Clock,
    title: "7j/7 toute la journée",
    description: "Ouvert du lundi au dimanche de 11h à 23h pour satisfaire toutes vos envies.",
  },
]

export function About() {
  return (
    <section id="apropos" className="py-24 bg-brand-dark-card">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Text side */}
          <div className="flex flex-col gap-6">
            <span className="text-primary font-bold text-sm uppercase tracking-widest">Notre histoire</span>
            <h2 className="font-black text-4xl md:text-5xl text-foreground leading-tight text-balance">
              La passion du snack,{" "}
              <span className="text-secondary">revisitée</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed text-pretty">
              Chez <strong className="text-foreground">Best Of</strong>, nous avons une obsession : vous offrir le meilleur. 
              Fondé avec la conviction que le fast-food peut rimer avec qualité, notre restaurant 
              est né de l'envie de créer des snacks qui font vraiment plaisir.
            </p>
            <p className="text-muted-foreground leading-relaxed text-pretty">
              Chaque kebab, chaque taco, chaque burger est préparé à la commande, avec des produits 
              frais sélectionnés avec soin. Pas de compromis sur la qualité — jamais.
            </p>

            {/* Stats */}
            <div className="flex gap-8 mt-2">
              {[
                { value: "5+", label: "Ans d'expérience" },
                { value: "500+", label: "Clients / jour" },
                { value: "4.8★", label: "Note moyenne" },
              ].map((stat) => (
                <div key={stat.label} className="flex flex-col">
                  <span className="font-black text-3xl text-secondary">{stat.value}</span>
                  <span className="text-muted-foreground text-sm">{stat.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Features grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {features.map(({ icon: Icon, title, description }) => (
              <div
                key={title}
                className="flex flex-col gap-3 p-6 rounded-2xl bg-brand-dark-surface border border-border hover:border-primary/40 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Icon size={22} className="text-primary" />
                </div>
                <h3 className="font-bold text-base text-foreground">{title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
