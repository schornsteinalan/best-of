import Image from "next/image"
import Link from "next/link"
import { ChevronDown } from "lucide-react"

export function Hero() {
  return (
    <section
      id="accueil"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-bg.jpg"
          alt="Best Of - Kebabs, Tacos, Burgers"
          fill
          className="object-cover"
          priority
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/65" />
        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-background to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 md:px-8 text-center flex flex-col items-center gap-6 pt-20">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-secondary/40 bg-secondary/10 text-secondary text-sm font-semibold uppercase tracking-widest">
          <span className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
          Ouvert maintenant
        </div>

        {/* Main title */}
        <h1 className="font-black text-5xl md:text-7xl lg:text-8xl text-foreground leading-tight text-balance">
          BEST <span className="text-primary">OF</span>
        </h1>

        <p className="text-xl md:text-2xl font-semibold text-secondary text-balance max-w-xl">
          Le meilleur du snack, au meilleur goût !
        </p>

        <p className="text-muted-foreground text-base md:text-lg max-w-lg text-pretty leading-relaxed">
          Kebabs, Tacos, et autres préparés avec passion — des ingrédients frais,
          des saveurs qui font la différence.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mt-2">
          <Link
            href="#commander"
            className="px-8 py-4 bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-base uppercase tracking-wider rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/30"
          >
            Commander maintenant
          </Link>
          <Link
            href="#menu"
            className="px-8 py-4 border-2 border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground font-bold text-base uppercase tracking-wider rounded-full transition-all duration-300 hover:scale-105"
          >
            Voir le menu
          </Link>
        </div>

        {/* Food pills */}
        <div className="flex flex-wrap justify-center gap-3 mt-4">
          {["Kebab", "Tacos", "Burger", "Box", "Frites", "Desserts"].map((item) => (
            <span
              key={item}
              className="px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-sm text-foreground text-sm font-medium border border-white/10"
            >
              {item}
            </span>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1 text-muted-foreground animate-bounce">
        <span className="text-xs uppercase tracking-widest font-medium">Découvrir</span>
        <ChevronDown size={18} />
      </div>
    </section>
  )
}
