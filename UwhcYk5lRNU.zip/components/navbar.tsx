"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X, ShoppingCart } from "lucide-react"
import { cn } from "@/lib/utils"

interface NavbarProps {
  cartCount?: number
  onCartClick?: () => void
}

const navLinks = [
  { href: "#accueil", label: "Accueil" },
  { href: "#menu", label: "Menu" },
  { href: "#apropos", label: "À propos" },
  { href: "#contact", label: "Contact" },
]

export function Navbar({ cartCount = 0, onCartClick }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-brand-dark/95 backdrop-blur-md shadow-lg shadow-black/40"
          : "bg-transparent"
      )}
    >
      <nav className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between h-18 py-4">
        {/* Logo */}
        <Link href="#accueil" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center font-black text-lg text-primary-foreground group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors duration-300">
            B
          </div>
          <span className="font-black text-2xl tracking-tight text-foreground">
            BEST <span className="text-primary">OF</span>
          </span>
        </Link>

        {/* Desktop links */}
        <ul className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className="text-muted-foreground hover:text-secondary font-semibold text-sm uppercase tracking-widest transition-colors duration-200 relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-secondary after:transition-all after:duration-300 hover:after:w-full"
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        {/* CTA + Cart */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={onCartClick}
            className="relative p-2 text-muted-foreground hover:text-secondary transition-colors"
            aria-label="Panier"
          >
            <ShoppingCart size={22} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary rounded-full text-xs font-bold flex items-center justify-center text-primary-foreground">
                {cartCount}
              </span>
            )}
          </button>
          <Link
            href="#commander"
            className="px-5 py-2.5 bg-primary hover:bg-secondary hover:text-secondary-foreground text-primary-foreground font-bold text-sm uppercase tracking-wider rounded-full transition-all duration-300 hover:scale-105"
          >
            Commander
          </Link>
        </div>

        {/* Mobile buttons */}
        <div className="flex md:hidden items-center gap-3">
          <button
            onClick={onCartClick}
            className="relative p-2 text-muted-foreground hover:text-secondary transition-colors"
            aria-label="Panier"
          >
            <ShoppingCart size={20} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary rounded-full text-xs font-bold flex items-center justify-center text-primary-foreground">
                {cartCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="p-2 text-foreground hover:text-secondary transition-colors"
            aria-label="Menu"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={cn(
          "md:hidden overflow-hidden transition-all duration-300 bg-brand-dark/98 backdrop-blur-md",
          mobileOpen ? "max-h-80 border-b border-border" : "max-h-0"
        )}
      >
        <ul className="flex flex-col px-6 py-4 gap-4">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="block text-muted-foreground hover:text-secondary font-semibold text-base uppercase tracking-widest transition-colors py-2"
              >
                {link.label}
              </Link>
            </li>
          ))}
          <li>
            <Link
              href="#commander"
              onClick={() => setMobileOpen(false)}
              className="block text-center px-5 py-3 bg-primary text-primary-foreground font-bold uppercase tracking-wider rounded-full transition-all duration-300 hover:bg-secondary hover:text-secondary-foreground"
            >
              Commander maintenant
            </Link>
          </li>
        </ul>
      </div>
    </header>
  )
}
