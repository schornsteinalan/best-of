import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

export async function POST() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  // Create orders table
  const { error } = await supabase.rpc('exec_sql', {
    sql_query: `
      CREATE TABLE IF NOT EXISTS orders (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        customer_name TEXT NOT NULL,
        customer_phone TEXT NOT NULL,
        customer_email TEXT,
        delivery_address TEXT,
        order_type TEXT NOT NULL CHECK (order_type IN ('sur_place', 'a_emporter', 'livraison')),
        items JSONB NOT NULL,
        subtotal DECIMAL(10,2) NOT NULL,
        delivery_fee DECIMAL(10,2) DEFAULT 0,
        total DECIMAL(10,2) NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled')),
        notes TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      );
    `
  })

  if (error) {
    // Table might already exist or RPC not available, try direct insert test
    const { error: testError } = await supabase.from('orders').select('id').limit(1)
    
    if (testError?.code === '42P01') {
      return NextResponse.json({ 
        error: 'Table does not exist. Please run the SQL script manually.',
        sql: 'See scripts/001_create_orders.sql'
      }, { status: 500 })
    }
    
    return NextResponse.json({ success: true, message: 'Table already exists' })
  }

  return NextResponse.json({ success: true, message: 'Migration completed' })
}
