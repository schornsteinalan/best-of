"use client"

import { useState, useEffect, useCallback } from "react"
import { 
  Clock, 
  CheckCircle, 
  ChefHat, 
  Package, 
  Truck, 
  XCircle,
  RefreshCw,
  Phone,
  Mail,
  MapPin,
  FileText,
  Euro
} from "lucide-react"
import { cn } from "@/lib/utils"

interface OrderItem {
  id: number
  name: string
  price: number
  quantity: number
}

interface Order {
  id: string
  customer_name: string
  customer_phone: string
  customer_email: string | null
  delivery_address: string | null
  order_type: "sur_place" | "a_emporter" | "livraison"
  items: OrderItem[]
  subtotal: number
  delivery_fee: number
  total: number
  status: "pending" | "confirmed" | "preparing" | "ready" | "delivered" | "cancelled"
  notes: string | null
  created_at: string
  updated_at: string
}

const STATUS_CONFIG = {
  pending: { label: "En attente", color: "bg-yellow-500", icon: Clock },
  confirmed: { label: "Confirmee", color: "bg-blue-500", icon: CheckCircle },
  preparing: { label: "En preparation", color: "bg-orange-500", icon: ChefHat },
  ready: { label: "Prete", color: "bg-green-500", icon: Package },
  delivered: { label: "Livree", color: "bg-gray-500", icon: Truck },
  cancelled: { label: "Annulee", color: "bg-red-500", icon: XCircle }
}

const ORDER_TYPE_LABELS = {
  sur_place: "Sur place",
  a_emporter: "A emporter",
  livraison: "Livraison"
}

export default function AdminPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<string>("all")
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)

  const fetchOrders = useCallback(async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/orders")
      if (response.ok) {
        const data = await response.json()
        setOrders(data)
      }
    } catch (error) {
      console.error("Failed to fetch orders:", error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchOrders()
    // Refresh every 30 seconds
    const interval = setInterval(fetchOrders, 30000)
    return () => clearInterval(interval)
  }, [fetchOrders])

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const response = await fetch("/api/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: orderId, status: newStatus })
      })
      
      if (response.ok) {
        setOrders(prev => 
          prev.map(order => 
            order.id === orderId 
              ? { ...order, status: newStatus as Order["status"] }
              : order
          )
        )
        if (selectedOrder?.id === orderId) {
          setSelectedOrder(prev => prev ? { ...prev, status: newStatus as Order["status"] } : null)
        }
      }
    } catch (error) {
      console.error("Failed to update order:", error)
    }
  }

  const filteredOrders = filter === "all" 
    ? orders 
    : orders.filter(order => order.status === filter)

  const orderCounts = {
    all: orders.length,
    pending: orders.filter(o => o.status === "pending").length,
    confirmed: orders.filter(o => o.status === "confirmed").length,
    preparing: orders.filter(o => o.status === "preparing").length,
    ready: orders.filter(o => o.status === "ready").length,
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-brand-dark-card border-b border-border sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-black text-foreground">
              <span className="text-primary">Best</span> Of - Dashboard
            </h1>
          </div>
          <button
            onClick={fetchOrders}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-semibold text-sm hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            <RefreshCw size={16} className={cn(loading && "animate-spin")} />
            Actualiser
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          {[
            { key: "all", label: "Toutes", count: orderCounts.all },
            { key: "pending", label: "En attente", count: orderCounts.pending, color: "text-yellow-500" },
            { key: "confirmed", label: "Confirmees", count: orderCounts.confirmed, color: "text-blue-500" },
            { key: "preparing", label: "En cours", count: orderCounts.preparing, color: "text-orange-500" },
            { key: "ready", label: "Pretes", count: orderCounts.ready, color: "text-green-500" },
          ].map(stat => (
            <button
              key={stat.key}
              onClick={() => setFilter(stat.key)}
              className={cn(
                "p-4 rounded-xl border transition-all",
                filter === stat.key
                  ? "bg-primary/10 border-primary"
                  : "bg-brand-dark-card border-border hover:border-primary/50"
              )}
            >
              <p className={cn("text-3xl font-black", stat.color || "text-foreground")}>
                {stat.count}
              </p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Orders List */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="text-lg font-bold text-foreground">
              Commandes {filter !== "all" && `(${STATUS_CONFIG[filter as keyof typeof STATUS_CONFIG]?.label || ""})`}
            </h2>
            
            {loading && orders.length === 0 ? (
              <div className="flex items-center justify-center py-12">
                <RefreshCw size={32} className="animate-spin text-primary" />
              </div>
            ) : filteredOrders.length === 0 ? (
              <div className="bg-brand-dark-card border border-border rounded-xl p-8 text-center">
                <p className="text-muted-foreground">Aucune commande</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredOrders.map(order => {
                  const StatusIcon = STATUS_CONFIG[order.status].icon
                  return (
                    <button
                      key={order.id}
                      onClick={() => setSelectedOrder(order)}
                      className={cn(
                        "w-full text-left p-4 rounded-xl border transition-all",
                        selectedOrder?.id === order.id
                          ? "bg-primary/10 border-primary"
                          : "bg-brand-dark-card border-border hover:border-primary/50"
                      )}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-bold text-foreground">{order.customer_name}</span>
                            <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                              {ORDER_TYPE_LABELS[order.order_type]}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground truncate">
                            {order.items.map(i => `${i.quantity}x ${i.name}`).join(", ")}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatDate(order.created_at)}
                          </p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <span className="font-bold text-secondary">{order.total.toFixed(2)}EUR</span>
                          <span className={cn(
                            "flex items-center gap-1 text-xs px-2 py-1 rounded-full text-white",
                            STATUS_CONFIG[order.status].color
                          )}>
                            <StatusIcon size={12} />
                            {STATUS_CONFIG[order.status].label}
                          </span>
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            )}
          </div>

          {/* Order Detail */}
          <div className="lg:col-span-1">
            {selectedOrder ? (
              <div className="bg-brand-dark-card border border-border rounded-xl p-5 sticky top-24">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-foreground">Detail commande</h3>
                  <span className="font-mono text-xs text-muted-foreground">
                    #{selectedOrder.id.slice(0, 8)}
                  </span>
                </div>

                {/* Customer Info */}
                <div className="space-y-2 mb-4 pb-4 border-b border-border">
                  <p className="font-semibold text-foreground">{selectedOrder.customer_name}</p>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone size={14} />
                    <a href={`tel:${selectedOrder.customer_phone}`} className="hover:text-primary">
                      {selectedOrder.customer_phone}
                    </a>
                  </div>
                  {selectedOrder.customer_email && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Mail size={14} />
                      <span>{selectedOrder.customer_email}</span>
                    </div>
                  )}
                  {selectedOrder.delivery_address && (
                    <div className="flex items-start gap-2 text-sm text-muted-foreground">
                      <MapPin size={14} className="mt-0.5 flex-shrink-0" />
                      <span>{selectedOrder.delivery_address}</span>
                    </div>
                  )}
                  {selectedOrder.notes && (
                    <div className="flex items-start gap-2 text-sm text-muted-foreground">
                      <FileText size={14} className="mt-0.5 flex-shrink-0" />
                      <span>{selectedOrder.notes}</span>
                    </div>
                  )}
                </div>

                {/* Items */}
                <div className="space-y-2 mb-4 pb-4 border-b border-border">
                  <h4 className="text-sm font-semibold text-foreground">Articles</h4>
                  <ul className="space-y-1">
                    {selectedOrder.items.map((item, idx) => (
                      <li key={idx} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{item.quantity}x {item.name}</span>
                        <span className="text-foreground">{(item.price * item.quantity).toFixed(2)}EUR</span>
                      </li>
                    ))}
                  </ul>
                  {selectedOrder.delivery_fee > 0 && (
                    <div className="flex justify-between text-sm pt-2">
                      <span className="text-muted-foreground">Livraison</span>
                      <span className="text-foreground">{selectedOrder.delivery_fee.toFixed(2)}EUR</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold pt-2">
                    <span className="flex items-center gap-1 text-foreground">
                      <Euro size={16} />
                      Total
                    </span>
                    <span className="text-secondary">{selectedOrder.total.toFixed(2)}EUR</span>
                  </div>
                </div>

                {/* Status Actions */}
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-foreground">Changer le statut</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {(["confirmed", "preparing", "ready", "delivered", "cancelled"] as const).map(status => {
                      const config = STATUS_CONFIG[status]
                      const Icon = config.icon
                      const isActive = selectedOrder.status === status
                      return (
                        <button
                          key={status}
                          onClick={() => updateOrderStatus(selectedOrder.id, status)}
                          disabled={isActive}
                          className={cn(
                            "flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all",
                            isActive
                              ? `${config.color} text-white`
                              : "bg-muted text-muted-foreground hover:bg-muted/80"
                          )}
                        >
                          <Icon size={14} />
                          {config.label}
                        </button>
                      )
                    })}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-brand-dark-card border border-border rounded-xl p-8 text-center">
                <p className="text-muted-foreground">
                  Selectionnez une commande pour voir les details
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
