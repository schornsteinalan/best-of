import type { Metadata } from 'next'
import { Barlow } from 'next/font/google'
import './globals.css'

const barlow = Barlow({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800', '900'],
  variable: '--font-barlow',
})

export const metadata: Metadata = {
  title: 'Best Of - Le meilleur du snack, au meilleur goût !',
  description: 'Restaurant Best Of - Kebabs, Tacos, Burgers & plus. Commandez en ligne ou venez nous rendre visite. Qualité premium, rapidité et goût incomparable.',
  keywords: 'kebab, tacos, burger, frites, snack, restaurant, fast food, Best Of',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className="bg-background">
      <body className={`${barlow.className} font-sans antialiased`}>
        {children}
      </body>
    </html>
  )
}
