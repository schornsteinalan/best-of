"use client"

import { useState, useCallback } from "react"
import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { PromoBanner } from "@/components/promo-banner"
import { Menu, type MenuItem } from "@/components/menu"
import { About } from "@/components/about"
import { Reviews } from "@/components/reviews"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"
import { Cart, type CartItem } from "@/components/cart"

export default function Page() {
  const [cartOpen, setCartOpen] = useState(false)
  const [cartItems, setCartItems] = useState<CartItem[]>([])

  const handleAddToCart = useCallback((item: MenuItem) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === item.id)
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      }
      return [...prev, { ...item, quantity: 1 }]
    })
    setCartOpen(true)
  }, [])

  const handleUpdateQuantity = useCallback((id: number, delta: number) => {
    setCartItems((prev) => {
      return prev
        .map((i) => (i.id === id ? { ...i, quantity: i.quantity + delta } : i))
        .filter((i) => i.quantity > 0)
    })
  }, [])

  const handleRemove = useCallback((id: number) => {
    setCartItems((prev) => prev.filter((i) => i.id !== id))
  }, [])

  const handleClearCart = useCallback(() => {
    setCartItems([])
  }, [])

  const totalCount = cartItems.reduce((s, i) => s + i.quantity, 0)

  return (
    <main>
      <Navbar
        cartCount={totalCount}
        onCartClick={() => setCartOpen(true)}
      />
      <Hero />
      <PromoBanner />
      <Menu onAddToCart={handleAddToCart} />
      <About />
      <Reviews />
      <Contact />
      <Footer />

      <Cart
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemove={handleRemove}
        onClearCart={handleClearCart}
      />
    </main>
  )
}
